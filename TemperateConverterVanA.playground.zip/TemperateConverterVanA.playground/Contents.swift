import UIKit

// I am making an app that will take an input of a temperature number value and type
// And will output in all three allowed types
// Allowed types will be Fahrenheit, Centigrade, and Kelvin
//Let's define our variables
var InputTemp: Double = 115.0
var InputTempType = "C"

var outputTempTypeF: Double = 0.0
var outputTempTypeC: Double = 0.0
var outputTempTypeK: Double = 0.0

//Let's do the work
// Input is Fahrenheit
if InputTempType == "F" {
    outputTempTypeF = InputTemp
    outputTempTypeC = (InputTemp-32)*(5/9)
    outputTempTypeK = outputTempTypeC + 273.15
}
// Input is Celcius
if InputTempType == "C" {
    outputTempTypeF = (InputTemp*(9/5)) + 32
    outputTempTypeC = InputTemp
    outputTempTypeK = outputTempTypeC + 273.15
}
// Input is Kelvin
if InputTempType == "K" {
    outputTempTypeC = InputTemp - 273.15
    outputTempTypeF = (outputTempTypeC*(9/5))+32
    outputTempTypeK = InputTemp
}

// Now, let's print it out
print("Your temperature of " + String(InputTemp) + " converted to Fahrenheit is " + String(outputTempTypeF))

print("Your temperature of " + String(InputTemp) + " converted to Celcius is " + String(outputTempTypeC))

print("Your temperature of " + String(InputTemp) + " converted to Kelvin is " + String(outputTempTypeK))
