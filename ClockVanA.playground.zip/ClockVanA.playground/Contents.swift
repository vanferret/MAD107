import UIKit

var startHour = 1
var startMinute = 58
var startsecond = 59

var currentTime = ""
var loopsLimit = 10
var loops = 0

// We are going to put a limit to the number of loops it is going to do so it doesn't loop forever
while loops < loopsLimit {
    // If the second is not 59, it is the only item we need to act upon
    // Otherwise, we set it to zero, and look to see if anything else needs to be reset
    if startsecond == 59 {
        // If the minutes are 59, we need to be reset to 0
        if startMinute == 59 {
            // If the hour is 12, reset to 1
            if startHour == 12 {
                startHour = 1
                startMinute = 0
                startsecond = 0
            // Otherwise, just add an hour
            } else {
                startHour += 1
                startMinute = 0
                startsecond = 0
            }
        // Otherwise, just add one
        } else {
            startMinute += 1
            startsecond = 0
        }
    } else {
        startsecond += 1
    }
//Display the current time with the increment
currentTime = String(startHour) + ":" + String(startMinute) + ":" + String(startsecond)
print(currentTime)
//Add to the loop so it will exit when we have hit the limit
loops += 1
    
// sleep a bit so we can keep time somewhat accurately
    do { sleep(1)}
}
