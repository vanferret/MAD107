import UIKit

// First going to get the enums ready for use by the Prius class object
enum model: String {
    case L_Eco
    case LE
    case XLE
    case Limited
    case LE_AWDe
    case XLE_AWDe
}

enum color: String {
    case Electric_Storm_Blue
    case Blizzard_Pearl
    case Classic_Silver_Metallic
    case Magnetic_Grey_Metallic
    case Midnight_Black_Metallic
    case SuperSonic_Red
    case Sea_Glass_Pearl
}
enum packages: String {
    case Advanced_Technology_Package
    case Premium_Convenience_Package
    case Advanced_Technology_Package_with_options
}
enum accessories: String {
    case Fifteen_inch_10_Spoke_Alloy_Wheels
    case Aero_Side_Splitter
    case All_Weather_Floor_Liner_Package
    case All_Weather_Floor_Liners
    case Allot_Wheel_Locks
    case Body_Side_Moldings
    case Cargo_Liner
    case Cargo_Net_Envelope
    case Carpet_Cargo_Mat
    case Carpet_Floor_Mats
    case Carpet_Mat_Package
    case Door_Edge_Guards
    case Emergency_Kit
    case First_Aid_Kit
    case Four_Season_Floor_Mat_Liner_Package
    case Illuminated_Door_Sills
    case Paint_Protection_Film_Front_Bumper
    case Paint_Protection_Film_Hood_Fenders_Mirror_Backs_and_Door_Cups
    case Preferred_Accessory_Package
    case Protection_Package_2
    case Protection_Package_3
    case Rear_Bumper_Applique
    case Rear_Bumper_Protector
    case Removable_Cross_Bars
    case Security_System
    case Universal_Tablet_Holder
}

class prius
{
    var myModel = ""
    var myColor = ""
    var packages: Array<String> = []
    var accessories: Array<String> = []
    
    init(modelIn: model = model.LE,
         colorIn: color = color.Blizzard_Pearl,
         packagesIn: packages? = nil,
         accessoriesIn: accessories? = nil)
    {
        self.myModel = modelIn.rawValue
        self.myColor = colorIn.rawValue
        
        // We have made the packages and accessories optional, so we'll try to unpack
        if let temp_pack = packagesIn{
            self.packages.append(temp_pack.rawValue)
        }
        
        if let temp_acc = accessoriesIn{
            self.accessories.append(temp_acc.rawValue)
        }
    }
    
    //Then we can make a method to add a Package
    func add_package(packageAddIn: packages? = nil) {
        if let temp_pack = packageAddIn{
            if !self.packages.contains(temp_pack.rawValue) {
                self.packages.append(temp_pack.rawValue)
            } else {
                print("This package has already been added!")
            }
        }
    }
    
    //And a method to remove a package
    func remove_package(packageRemove: packages? = nil) {
        if let temp_pack = packageRemove{
            if self.packages.contains(temp_pack.rawValue){
                var getIndex = 0
                for check in self.packages.enumerated(){
                    if check.element == temp_pack.rawValue{
                        getIndex = check.offset
                    }
                }
                self.packages.remove(at: getIndex)
            } else {
                print("This package has not been added yet!")
            }
        }
    }
    
    //And the same for Accessories: Add
    func add_acc(accAddIn: accessories? = nil) {
        if let temp_acc = accAddIn{
            if !self.accessories.contains(temp_acc.rawValue) {
                self.accessories.append(temp_acc.rawValue)
            } else {
                print("This accessory has already been added!")
            }
        }
    }
    //Remove
    func remove_acc(accRemove: accessories? = nil) {
        if let temp_acc = accRemove{
            if self.accessories.contains(temp_acc.rawValue){
                var getIndex = 0
                for check in self.accessories.enumerated(){
                    if check.element == temp_acc.rawValue{
                        getIndex = check.offset
                    }
                }
                self.accessories.remove(at: getIndex)
            } else {
                print("This accessory has not yet been added!")
            }
        }
    }
}

//Let's instantiate our Prius. We'll start with no packages or Accessories
var myPrius = prius(modelIn: model.LE_AWDe, colorIn: color.SuperSonic_Red, packagesIn: nil, accessoriesIn: nil)

//We didn't start with any packages or accessories, but we can add them
myPrius.add_package(packageAddIn: packages.Advanced_Technology_Package)
myPrius.add_acc(accAddIn: accessories.All_Weather_Floor_Liners)
myPrius.add_acc(accAddIn: accessories.Cargo_Liner)

// We can print out the model and color easily enough
print(myPrius.myModel)
print(myPrius.myColor)

//But we'll have to loop the arrays to print out the options
for a in myPrius.packages {
    print("Included Package: \(a)")
}

for a in myPrius.accessories {
    print("Included Accessory: \(a)")
}
