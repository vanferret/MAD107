import UIKit

//So what can I do????? I think I will do a tongue twister based on the children's Rhyme

//First let's set up the constants, which in this case we'll make three kids names
// and the parts of the rhyme that never change
var childName = "Ella"

let stat_rhyme_p1 = "bo-b"
let stat_rhyme_p2 = ", banana-fana, fo-f"
let stat_rhyme_p3 = ", bee, bye, bo-b"

//Then let's set up the main place holders
var child_rhyme = ""

// Then let's do some discovery to find out the place of the first vowel
var child_consonant1 = ""
var check_char = ""

for char in childName{
    check_char = String(char).lowercased()
    if check_char == "a" || check_char == "e" || char == "i" || char == "o" || char == "u" {
        break
    }
    child_consonant1 = child_consonant1 + String(char)
    child_consonant1 = child_consonant1.trimmingCharacters(in: .whitespacesAndNewlines)
}

var child_remainder1 = childName.replacingOccurrences(of: child_consonant1, with: "").lowercased()

child_rhyme = childName + ", " + childName + ", " + stat_rhyme_p1 + child_remainder1 + stat_rhyme_p2
child_rhyme = child_rhyme + child_remainder1 + stat_rhyme_p3 + child_remainder1 + ", " + childName + "!"
print(child_rhyme)
