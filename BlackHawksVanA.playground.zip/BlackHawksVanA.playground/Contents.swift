import UIKit

// Define a dictionary to hold all of the players by Number as key
var players: [Int:[String:String]] = [:]
// Define a temporary dictionary to hold player info as it gets added to the overall dictionary
var player:[String:String] = [:]

// Read in the data in separate arrays, and add them to an array of arrays
var Overall: Array<Array<String>> = []
var array1: [String] = ["27","Adam Boqvist","71","Aug","SWE","19"]
var array2: [String] = ["44","Calvin de Haan","73","May","CAN","28"]
var array5: [String] = ["39","Dennis Gilbert","74","Oct","USA","23"]
var array6: [String] = ["56","Erik Gustafsson","72","Mar","SWE","27"]
var array7: [String] = ["2","Duncan Keith","73","Jul","CAN","36"]
var array8: [String] = ["68","Slater Koekkoek","74","Feb","CAN","25"]
var array9: [String] = ["6","Olli Maatta","74","Aug","FIN","25"]
var array10: [String] = ["5","Connor Murphy","76","Mar","USA","26"]
var array11: [String] = ["7","Brent Seabrook","75","Apr","CAN","34"]
var array12: [String] = ["50","Corey Crawford","74","Dec","CAN","34"]
var array13: [String] = ["40","Robin Lehner","76","Jul","SWE","28"]
var array14: [String] = ["91","Drake Caggiula","70","Jun","CAN","25"]
var array15: [String] = ["22","Ryan Carpenter","72","Jan","USA","28"]
var array16: [String] = ["77","Kirby Dach","76","Jan","CAN","18"]
var array17: [String] = ["12","Alex DeBrincat","67","Dec","USA","21"]
var array18: [String] = ["36","Matthew Highmore","71","Feb","CAN","23"]
var array19: [String] = ["64","David Kampf","74","Jan","CZE","24"]
var array20: [String] = ["88","Patrick Kane","70","Nov","USA","31"]
var array21: [String] = ["8","Dominik Kubalik","74","Aug","CZE","24"]
var array22: [String] = ["92","Alex Nylander","73","Mar","CAN","21"]
var array23: [String] = ["20","Brandon Saad","73","Oct","USA","27"]
var array24: [String] = ["65","Andrew Shaw","71","Jul","CAN","28"]
var array25: [String] = ["95","Dylan Sikura","71","Jun","CAN","24"]
var array26: [String] = ["15","Zack Smith","74","Apr","CAN","31"]
var array27: [String] = ["17","Dylan Strome","75","Mar","CAN","22"]
var array28: [String] = ["19","Jonathan Toews","74","Apr","CAN","31"]

Overall.append(array1)
Overall.append(array2)
Overall.append(array5)
Overall.append(array6)
Overall.append(array7)
Overall.append(array8)
Overall.append(array9)
Overall.append(array10)
Overall.append(array11)
Overall.append(array12)
Overall.append(array13)
Overall.append(array14)
Overall.append(array15)
Overall.append(array16)
Overall.append(array17)
Overall.append(array18)
Overall.append(array19)
Overall.append(array20)
Overall.append(array21)
Overall.append(array22)
Overall.append(array23)
Overall.append(array24)
Overall.append(array25)
Overall.append(array26)
Overall.append(array28)

//Now that we have all of the data, let's create the dictionary items
for input in Overall {
    player["Name"] = input[1]
    player["Height"] = input[2]
    player["BirthMonth"] = input[3]
    player["Country"] = input[4]
    player["age"] = input[5]
    let tempInt = Int(input[0]) ?? 0
    
    players[tempInt] = player
}
// Let's print it so we can check it
//print(players)

// Now let's do the other things we need to do
//Setting up the arrays of tuples, since we need multiple data types to pull this off
var agearray: Array<(String,Int)> = []
var country_array: Array<(String,String)> = []
var country_dict: [String:Int] = [:]
var age_sum = 0
var height_sum = 0

// Then we'll loop through the dictionary and get the bits and pieces we need
// We could probably do separate loops for each item for clarity in the code
for player_vals in players.values {
    //Get the name data for both age and country
    let temp_name = player_vals["Name"] ?? ""
    let temp_age = player_vals["age"] ?? ""
    let temp_age2 = Int(temp_age) ?? 0
    // Age appending
    let temp_agetuple: (String,Int) = (temp_name,temp_age2)
    agearray.append(temp_agetuple)
    //Country appending
    let temp_country = player_vals["Country"] ?? ""
    let temp_countrytuple: (String,String) = (temp_name,temp_country)
    country_array.append(temp_countrytuple)
    
        //Before we move on, we have the country, let's check if it already exists in the dict
    if let val = country_dict[temp_country] {
        country_dict[temp_country] = val + 1
    } else {
        country_dict[temp_country] = 1
    }
    
    // Let's sum the age ongoing, since we already had to extract above
    age_sum += temp_age2
    
    //Now let's deal with the height
    let temp_height = player_vals["Height"] ?? ""
    let temp_height2 = Int(temp_height) ?? 0
    height_sum += temp_height2
}

//And sort and print the age tuple
    let sortedAgeTuple = agearray.sorted(by: { $0.1 < $1.1 })
    print(sortedAgeTuple)

//And sort and print the country array tuple
    let sortedCountryTuple = country_array.sorted(by: { $0.1 < $1.1 })
    print(sortedCountryTuple)

// To get the averages, we need to know the count from the dictionary, sum(s) done in loop
    let player_count = players.count
    let average_age = age_sum / player_count
    let average_height = height_sum / player_count

// Can we get the country in tuple?
    //let dictKeyDec = country_dict.sorted(by: { $0.value > $1.value })
    let winning_country = country_dict.max { a, b in a.value < b.value }
    //let winning_country_val = winning_country?.value
    //print(dictKeyDec)
    print("The country with the most native players is \(winning_country)!")

// And we'll print it out
    print("The average age of BlackHawks team members is \(average_age) years.")
    print("The average height of BlackHawks team members is \(average_height) inches.")
