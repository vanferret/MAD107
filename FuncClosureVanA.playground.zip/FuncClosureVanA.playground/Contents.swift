import UIKit

// Ok, so every morning I make the same breakfast, but it is so automatic that if I get interrupted, I have to readjust! here is a nice quick way to get a reminder

var breakfastTheWayILikeIt: Array<String> = []
breakfastTheWayILikeIt.append("Fill the teapot with water")
breakfastTheWayILikeIt.append("Turn the left knob to start the burner. Leave on High")
breakfastTheWayILikeIt.append("Add 4 Tbs coffee grounds to French Press")
breakfastTheWayILikeIt.append("Place frying pan over right burner.")
breakfastTheWayILikeIt.append("Turn the right knob to start the burner. Leave on Med")
breakfastTheWayILikeIt.append("Gather eggs and bacon from fridge")
breakfastTheWayILikeIt.append("Fry bacon in pan, place on plate")
breakfastTheWayILikeIt.append("Fry eggs in bacon grease, place on plate")
breakfastTheWayILikeIt.append("When kettle whistles, turn off")
breakfastTheWayILikeIt.append("Set timer for three minutes")
breakfastTheWayILikeIt.append("When timer sounds, fill french press to top with water from kettle")
breakfastTheWayILikeIt.append("Let steep for 6 minutes")
breakfastTheWayILikeIt.append("Eat food while coffee steeps")
breakfastTheWayILikeIt.append("Press coffee, fill favorite mug")
breakfastTheWayILikeIt.append("Add Cream")
breakfastTheWayILikeIt.append("You are now slightly less grumpy and ready to speak without cursing!")

func breakfastOrders(instructs: [String]) -> () -> Void {
    let reminders: () -> Void = {
        for direction in instructs {
            print("\(direction)")
        }
    }
    return reminders
}

var getMyReminder = breakfastOrders(instructs: breakfastTheWayILikeIt)
getMyReminder()
