import UIKit

// Enum to elaborate on the options for doneness
enum Doneness {
    case Rare
    case Medium_Rare
    case Medium
    case Well
    case Char
}

// create the structure to house the information about the burger
struct burger {
    //creating instance vars and optionals
    var cookedto:Doneness = Doneness.Medium
    var cheeseType: String = "American"
    var pickles: Bool = true
    var lettuce: Bool = true
    var tomato: Bool = true
    var special: String?
}

//Order my burger
var myBurger = burger(cookedto: Doneness.Medium, cheeseType: "Swiss", pickles: false, lettuce: true, tomato: false, special: "Add mushrooms")

//Then let's get some information about the burger so we can repeat it back to the customer
var printDesc = myBurger.cookedto
var printCheese = " with " + myBurger.cheeseType + " cheese "

var printpickles = ""
if myBurger.pickles {
    printpickles = ", with pickles"
} else {
    printpickles = ", with no pickles"}

var printlettuce = ""
if myBurger.lettuce {
    printlettuce = ", with lettuce"
} else {
    printlettuce = ", with no lettuce"}

var printTomato = ""
if myBurger.tomato {
    printpickles = ", with tomato"
} else {
    printpickles = ", with no tomato"}

var printSpecialFinal = ""
if let printSpecial = myBurger.special {
    printSpecialFinal = " With special instructions to: " + printSpecial
}

print("Cooked to \(printDesc)" + printCheese + printpickles + printlettuce + printTomato + "." + printSpecialFinal)
