import UIKit

// Define a dictionary to hold all of my cars
var cars: [String:[String:String]] = [:]
// Define a temporary dictionary to each cars' info as it gets added to the overall dictionary
var car:[String:String] = [:]

// Read in the data in separate arrays, and add them to an array of arrays
var input_carr_array: Array<Array<String>> = []
//Make, Model, Year, Mileage, Value
var array1: [String] = ["Ford","Bronco","1995","72400","4000"]
var array2: [String] = ["Subaru","Outback","2013","96550","12500"]
var array3: [String] = ["Subaru","Forester","1999","242300","1200"]

input_carr_array.append(array1)
input_carr_array.append(array2)
input_carr_array.append(array3)

//Now that we have all of the car data, let's create the dictionary items
for input in input_carr_array {
    let car_handle = input[1]
    car["Make"] = input[0]
    car["Model"] = car_handle
    car["Year"] = input[2]
    car["Mileage"] = input[3]
    car["Value"] = input[4]
    
    cars[car_handle] = car
}

// I want to find the average age of my cars with a calculation and the most valuable
//Setting up the arrays of tuples, since I need multiple data types
var agearray: Array<(String,Int)> = []
var price_array: Array<Int> = []
var age_sum = 0

// Then we'll loop through the dictionary and get the bits and pieces we need
// We could probably do separate loops for each item for clarity in the code
for car_vals in cars.values {
    //Get the name data for both age and country
    let temp_name = car_vals["Model"] ?? ""
    let temp_year = car_vals["Year"] ?? ""
    let temp_year2 = Int(temp_year) ?? 0
    
    // Age appending
    let temp_agetuple: (String,Int) = (temp_name,2019 - temp_year2)
    agearray.append(temp_agetuple)
    // Let's sum the age ongoing, since we already had to extract above
    age_sum += 2019 - temp_year2
    
    // Appending to the array of values
    let temp_value = car_vals["Value"] ?? ""
    let temp_value2 = Int(temp_value) ?? 0
    price_array.append(temp_value2)
}

// Average age
    let car_count = cars.count
    let average_age = age_sum / car_count

// Get the most valuable price
    let most_valuable = price_array.max()

// And we'll print it out
    print("The average age of your cars is \(average_age) years.")
    print("The most valuable car is worth \(most_valuable) dollars.")
