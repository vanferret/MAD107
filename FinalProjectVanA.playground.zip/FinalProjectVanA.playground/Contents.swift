import UIKit


// I suppose I can start out by adding a couple of enumerations

enum toDoTypes: String {
    case Reminder
    case Task
    case Meeting
}

enum priority_level: String {
    case High
    case Medium
    case Low
}

class task
{
    // The object itself is actually going to be quite simple. We will use the list class/object to controll all this
    var taskType = "Task"
    var urgent: Bool = false
    var description: String = ""
    var priority: String = "Low"
    //Dates seem incredibly ridiculous, not gonna do it. Not now anyway
    var dueDate: String = "1/1/2020"
    
    init (typeIn: String,isUrgent: Bool, priorityIn: String,
          descriptionIn: String, dueDateIn: String) {
        // Let's grab the type and override the default if they pass one
        self.taskType = typeIn
        self.urgent = isUrgent
        self.priority = priorityIn
        self.description = descriptionIn
        self.dueDate = dueDateIn
    }
    
    // Let's make a function so we can report out on all attributes
    func getTotalDescriptor()-> String{
        var strOut = "The Task Description is '\(self.description)"
        strOut += ", the Task Type is " + self.taskType
        if (self.urgent){
            strOut += ", task is marked Urgent"
        } else {
            strOut += ", task is not marked Urgent"
        }
        strOut += ", the priority is \(self.priority)"
        strOut += ", and the Due Date is \(dueDate)"
        
        return strOut
    }
    // Define all of the more specific getters
    func getType()-> String{
        return self.taskType
    }
    func getUrgency()-> Bool{
        return self.urgent
    }
    func getpriority()-> String{
        return self.priority
    }
    func getdescription()-> String{
        return self.description
    }
    func getDueDate()-> String{
        return self.dueDate
    }

    // Define all of the more specific setters
    func setType(typeIn: String){
        self.taskType = typeIn
    }
    func setUrgency(urgencyIn: Bool){
        self.urgent = urgencyIn
    }
    func setpriority(priorityIn: String){
        self.priority = priorityIn
    }
    func setdescription(descriptionIn: String){
        self.description = descriptionIn
    }
    func setDueDate(dueDateIn:String){
        self.dueDate = dueDateIn
    }
    
}

class list
{
    var tasks = [task]()
    var complete_tasks = [task]()
//    var tempTask: task
    var taskType: String = "Task"
    var urgent: Bool = false
    var description: String = ""
    var priority: String = "Low"
    //Dates seem incredibly ridiculous, not gonna do it. Not now anyway
    var dueDate: String = "1/1/2020"
    
    init () {
        //I am not sure what I want here yet
        print("It has begun")
        
    }
    
    //I am going to need a method to add a task
    func addTask (typeIn: toDoTypes? = nil,isUrgent: Bool? = nil,priorityIn: priority_level? = nil, descriptionIn: String? = nil, dueDateIn: String? = nil) {
        var tempTask: task
        // Let's grab the type and override the default if they pass one
        if let myType = typeIn{
        self.taskType = myType.rawValue
        }
        //Same for whether or not it is marked especially urgent
        if let myUrgent = isUrgent{
        self.urgent = myUrgent
        }
        if let myPriority = priorityIn{
        self.priority = myPriority.rawValue
        }
        if let myDescription = descriptionIn{
        self.description = myDescription
        }
        if let myDueDate = dueDateIn{
        self.dueDate = myDueDate
        }
        tempTask = task(typeIn: self.taskType, isUrgent: self.urgent,
                             priorityIn: self.priority, descriptionIn: self.description,
                             dueDateIn: self.dueDate)
        self.tasks.append(tempTask)
    }
    
    //I am going to need a way to retrieve a task, though we may not want this to be for general use
    func getTask(strTaskName: String)-> task{
        //We'll set up a default to initialize the object
        var temp_task: task = task(typeIn: "", isUrgent: false, priorityIn: "", descriptionIn: "",                          dueDateIn: "")
        // And grab the actual item
        for a in tasks{
            if a.description == strTaskName {
                temp_task = a
                return temp_task
            }
        }
        return temp_task
    }
    
    func getDescriptions()-> String{
        var descriptions: String = ""
        for a in tasks{
            descriptions +=  a.getdescription() + "\n"
        }
        return descriptions
    }
    
    func getFullDataDescriptions()-> String{
        var descriptions: String = ""
        for a in tasks{
            descriptions +=  a.getTotalDescriptor() + "\n"
        }
        return descriptions
    }
    
    func completeTask(taskName: String){
        // We'll loop the items, and see if we can find the item
        // for which we'll need an Int
        var index = 0
        var found = false
        for a in tasks{
            if a.description == taskName {
                tasks.remove(at: index)
                complete_tasks.append(a)
                print(taskName + " has been moved to the completed list.")
                found = true
                break
            }
            index += 1
        }
        //If the item was not found, we'll also let them know
        if (!found) {
            print("The requested item was not found, so not closed. Please review task name.")
        }
    }
    
    //I am going to need a way to update a task, let's start with updating a priority
    func updatePriority(taskName: String, priorityIn: priority_level? = nil){
        //Track whether we found the task or not
        var found = false
        var newPriority = ""
        //Let's check out the priority item to make sure it is good
        if let myPriority = priorityIn{
            newPriority = myPriority.rawValue
        }
        for a in tasks{
            if a.getdescription() == taskName {
                a.setpriority(priorityIn: newPriority)
                print("The priority for \(taskName) has been updated to \(newPriority).")
                found = true
                break
            }
        }
        //If the item was not found, we'll also let them know
        if (!found) {
            print("The requested item was not found, so priority was not updated. Please review task name.")
        }
        
    }
    //Now, let's updated the Due Date
    func updateDueDate(taskName: String, dueDateIn: String? = nil){
        //Track whether we found the task or not
        var found = false
        var newDueDate = ""
        //Let's check out the priority item to make sure it is good
        if let myDueDate = dueDateIn{
            newDueDate = myDueDate
        }
        for a in tasks{
            if a.getdescription() == taskName {
                a.setDueDate(dueDateIn: newDueDate)
                print("The due date for \(taskName) has been updated to \(newDueDate).")
                found = true
                break
            }
        }
        //If the item was not found, we'll also let them know
        if (!found) {
            print("The requested item was not found, so due date was not updated. Please review task name.")
        }
        
    }
}

// Now we are going to start adding items to our To Do List
// But first we need to create the list itself
var startIt = list()

// Then add some items to do
startIt.addTask(typeIn: toDoTypes.Task, isUrgent: true, priorityIn: priority_level.High, descriptionIn: "Mail Letter to Santa", dueDateIn: "12/15/2020")
startIt.addTask(typeIn: toDoTypes.Task, isUrgent: false, priorityIn: priority_level.High, descriptionIn: "Wrap Presents", dueDateIn: "12/24/2020")
startIt.addTask(typeIn: toDoTypes.Reminder, isUrgent: false, priorityIn: priority_level.Low, descriptionIn: "Christmas is coming!", dueDateIn: "12/24/2020")

//Let's get a list of the descriptions
var descriptions = startIt.getDescriptions()
print(descriptions)

//Then we'll close out a task and reprint the descriptions
    startIt.completeTask(taskName: "Wrap Presents")
    descriptions = startIt.getDescriptions()
    print(descriptions)

    descriptions = startIt.getFullDataDescriptions()
    print(descriptions)

// Let's make a couple of updates and then reprint the descriptions
    startIt.updateDueDate(taskName: "Mail Letter to Santa", dueDateIn: "12/20/2019")
    startIt.updatePriority(taskName: "Christmas is coming!", priorityIn: priority_level.Medium)

    descriptions = startIt.getFullDataDescriptions()
    print(descriptions)
