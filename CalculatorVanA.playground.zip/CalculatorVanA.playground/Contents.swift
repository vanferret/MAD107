import UIKit

// So, I am building a calculator.
// First I will define the variables I need
//I am going to assume the user can enter two variables to begin with, and we are going to assume they are doubles for now
var InputNumber1: Double = 11.0
var InputNumber2: Double = 3.0
var OutputAdd: Double = 0.0
var OutputSubtract: Double = 0.0
var OutputMultiply: Double = 0.0
var OutputDivide: Double = 0.0
var OutputPercentage: Double = 0.0


//Now to define my operators
OutputAdd = InputNumber1 + InputNumber2
OutputSubtract = InputNumber1 - InputNumber2
OutputMultiply = InputNumber1 * InputNumber2
OutputDivide = InputNumber1 / InputNumber2
OutputPercentage = InputNumber1 / InputNumber2 * 100

//And then we can print it all out
print("The addition of " + String(InputNumber1) + " and " + String(InputNumber2) + " equals " + String(OutputAdd))
print("The subtraction of " + String(InputNumber1) + " and " + String(InputNumber2) + " equals " + String(OutputSubtract))
print("The multiplication of " + String(InputNumber1) + " and " + String(InputNumber2) + " equals " + String(OutputMultiply))
print("The division of " + String(InputNumber1) + " and " + String(InputNumber2) + " equals " + String(OutputDivide))
print("The percentage of " + String(InputNumber1) + " over " + String(InputNumber2) + " equals " + String(OutputPercentage) + "%")
