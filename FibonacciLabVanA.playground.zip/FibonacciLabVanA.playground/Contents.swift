import UIKit

var tracker: Array<Double> = [0,1]
var outputArray: Array<Double> = []
var loopLimit = 1000
var loopTracker = 0
var curCount = 0
var prior = 0.0
var priorPrior = 0.0
var newVal = 0.0

func addLastTwoIntoNew (inputArray: Array<Double>) -> Array<Double> {
    curCount = inputArray.count
    prior = inputArray[curCount - 2]
    priorPrior = inputArray[curCount - 1]
    newVal = prior + priorPrior
    
    outputArray = inputArray
    outputArray.append(newVal)
    print(outputArray)
    return outputArray
    
}

while loopTracker < loopLimit {
    
    tracker = addLastTwoIntoNew(inputArray: tracker)
    loopTracker += 1
}

print(tracker)
